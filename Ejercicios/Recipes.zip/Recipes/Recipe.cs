//-------------------------------------------------------------------------
// <copyright file="Recipe.cs" company="Universidad Católica del Uruguay">
// Copyright (c) Programación II. Derechos reservados.
// </copyright>
//-------------------------------------------------------------------------

using System;
using System.Collections;

namespace Full_GRASP_And_SOLID
{
    public class Recipe
    {
        private ArrayList steps = new ArrayList();

        public Product FinalProduct { get; set; }

        public void AddStep(Step step)
        {
            Check.Precondition(step != null,"Paso nulo");
            Check.Precondition(this.steps != null,"Lista de pasos nula");
            this.steps.Add(step);
            Check.Postcondition(this.steps.Count>0,"No se agrego el paso correctamente");
            Check.Postcondition(this.steps.Contains(step),"No se agrego el paso correctamente");
            Check.Postcondition(this.steps[this.steps.Count-1] == step,"No se agrego el paso correctamente");
        }

        public void RemoveStep(Step step)
        {
            Check.Precondition(step != null,"Paso nulo");
            Check.Precondition(this.steps != null,"Lista de pasos nula");
            Check.Precondition(this.steps.Contains(step),"No existe el paso a eliminar en la lista");
            this.steps.Remove(step);
            Check.Postcondition(!this.steps.Contains(step),"No se elimino de la lista de pasos correctamente");
        }

        public void PrintRecipe()
        {
            Check.Precondition(this.FinalProduct!=null,"Producto final nulo");
            Console.WriteLine($"Receta de {this.FinalProduct.Description}:");
            Check.Precondition(this.steps!=null,"Lista de pasos nula");
            foreach (Step step in this.steps)
            {
                Check.Precondition(step.Input!=null,"Valor de input nulo");
                Check.Precondition(step.Equipment!=null,"Valor de equipo nulo");
                Console.WriteLine($"{step.Quantity} de '{step.Input.Description}' " +
                    $"usando '{step.Equipment.Description}' durante {step.Time}");
            }
        }
    }
}