//-------------------------------------------------------------------------------
// <copyright file="Step.cs" company="Universidad Católica del Uruguay">
// Copyright (c) Programación II. Derechos reservados.
// </copyright>
//-------------------------------------------------------------------------------

namespace Full_GRASP_And_SOLID
{
    public class Step
    {
        public Step(Product input, double quantity, Equipment equipment, int time)
        {
            this.Quantity = quantity;
            this.Input = input;
            this.Time = time;
            this.Equipment = equipment;
        }

        private Product input;
        public Product Input 
        { 
            get{return this.input;} 
            set
            {
                Check.Precondition(value!=null,"Input no puede ser nulo");
                this.input = value;
                Check.Postcondition(this.input == value,"El set de input no funciono correctamente");
                Check.Invariant(this.input!=null,"Input no puede ser nulo");
            } 
        }

        private double quantity;
        public double Quantity 
        { 
            get{return this.quantity;} 
            set
            {
                Check.Precondition(value>0,"El valor de cantidad debe ser mayor a cero");
                this.quantity=value;
                Check.Postcondition(this.quantity==value,"El set de cantidad no funciono correctamente");
                Check.Invariant(this.quantity>0,"El valor de cantidad debe ser mayor a cero");
            } 
        }

        private int time;
        public int Time
        { 
            get{return this.time;} 
            set
            {
                Check.Precondition(value>0,"El valor de tiempo debe ser mayor a cero");
                this.time=value;
                Check.Postcondition(this.time==value,"El set de tiempo no funciono correctamente");
                Check.Invariant(this.time>0,"El valor de tiempo debe ser mayor a cero");
            } 
        }

        private Equipment equipment;
        public Equipment Equipment 
        { 
            get{return this.equipment;} 
            set
            {
                Check.Precondition(value!=null,"Equipment no puede ser nulo");
                this.equipment = value;
                Check.Postcondition(this.equipment == value,"El set de equipment no funciono correctamente");
                Check.Invariant(this.equipment!=null,"Equipment no puede ser nulo");
            }
        }
    }
}